Author: Andrew Burgos
Hours analyzing: 5hrs
Hours setting up: 10hrs
Hours coding: 5hrs
Collaboration: Received a lot of help from Max Ettelson in figuring out how everything works
Implementation: Everything has been implemented correctly
