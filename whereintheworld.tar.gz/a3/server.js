var link = require('http');
var express = require('express');
var parser = require('body-parser');
var validator = require('validator');
var app = express();

app.use(parser.json());
app.use(parser.urlencoded({ 
    extended: true 
}));

/*Initializes my instance of mongo */
var initialize = process.env.MONGOLAB_URI || process.env.MONGOHQ_URL || 'mongodb://localhost/test';
var mongo = require('mongodb');
var db = mongo.Db.connect(initialize, function(error, databaseConnection) {
    db = databaseConnection;
});

/*Retrieves data cited in link.get and appends data onto variable info*/
app.get('/redline.json',function(request, response){
        response.header("Access-Control-Allow-Origin", "*");
        response.header("Access-Control-Allow-Headers", "X-Requested-With");
        response.set('Content-Type', 'application/json');
        var info = '';
        link.get("http://developer.mbta.com/lib/rthr/red.json", function(apiresponse) {
	        apiresponse.on('data', function(chunk) {
		        info += chunk;
	        });
	        apiresponse.on('end', function() {
		        response.send(info);
	        });
	}).on('error', function(error) {
		response.send(500);
	});
});

/*Sends information to the data server*/
app.post('/sendLocation', function(request, response) {
	response.header("Access-Control-Allow-Origin", "*");
	response.header("Access-Control-Allow-Headers", "X-Requested-With");
	var login = request.body.login;
	var lat = request.body.lat;
	var lng = request.body.lng;
	var string = new Date().toUTCString();
	var dataInsert = {
	        "login": login,
	        "lat":parseFloat(lat),
	        "lng":parseFloat(lng),
	        "created": string,
	};
	db.collection('locations', function(er, collection) {
		var data = [];
	        var resText = [];
	        if (!er){
		        var id = collection.insert(dataInsert, function(err, saved) {
			        if(!err) {
			                collection.find().sort({
					    created: -1
					}).limit(100).toArray(function(err, resJson){
				            response.send(JSON.stringify({
						characters:[],  
						students:resJson
					    }));
					});
			                
                                 }
		        });
		}
	});
});

/*String concatenates data*/
app.get('/', function(request, response) {
        response.set('Content-Type', 'text/html');
        var index = '';
	db.collection('locations', function(er, collection) {
		collection.find().toArray(function(err, cursor) {
		    if (err) {
			response.send('<!DOCTYPE HTML><html><body><h1>This is wrong</h1></body></html>');
		    } else {
			index += "<!DOCTYPE HTML><html><head><title>Where err body?</title></head><body><h1>Hello?</h1>";
			for (var count = 0; count < cursor.length; count++) {
				index += "<p>login: " + cursor[count].login + "</p>";
				var alt_lat = parseFloat(cursor[count].lat);
				var alt_lng = parseFloat(cursor[count].lng);
				index += "<p>lat: "+lat1+"</p>";
				index += "<p>lng: "+lng1+"</p>"; 
				index += "<p>created: " + cursor[count].created + "</p>";
				index += "<p></p>";
		    }
			index += "</body></html>";
			response.send(index);
		   		    }
		});
	});
});

/*Sets header and follows path to retrieve JSON data*/
app.get('/locations.json', function (request, response) {
	response.header("Access-Control-Allow-Origin", "*");
	response.header("Access-Control-Allow-Headers", "X-Requested-With");
	var q = request.query;
	var json =JSON.stringify(q);
	var searchString = JSON.parse(json).login;
	var data = [];
	response.set('Content-Type', 'text/html');
	db.collection('locations', function(er, collection) {
		if (er) {
			response.send(500);
		}
		else {
			collection.find().sort({
			    created: -1
			}).limit(100).toArray(function(err, resJson){
			    response.send(JSON.stringify({
				characters:[],  
				students:resJson
			    }));
			});
		}
	});
});

app.listen(process.env.PORT || 5000);
